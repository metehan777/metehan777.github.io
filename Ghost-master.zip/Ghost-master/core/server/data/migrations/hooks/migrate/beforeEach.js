var Promise = require('bluebird');

module.exports = function beforeEach() {
    return Promise.resolve();
};
