module.exports = {
    get options() {
        return require('./options');
    }
};
